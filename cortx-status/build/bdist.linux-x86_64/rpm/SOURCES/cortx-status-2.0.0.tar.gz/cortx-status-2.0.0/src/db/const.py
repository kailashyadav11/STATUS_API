HOST = "127.0.0.1"
PORT = 8000
UPGRADE_DB = "/opt/seagate/cortx/status/db/upgrade.json"
HEALTH_DB = "/opt/seagate/cortx/status/db/health.json"
